# dockerpractica
Se necesita correr el comando en la consola en la carpeta dockerpractica docker compose up
Una vez el comando haya sido ejecutado, se necesita que el puerto del mismo esté libre, el puerto es 8080:80
De no tener el puerto 8080:80 libre, cambiar el archivo docker-compose.yml para el puerto que se acomode
*Si se modificó el archivo, necesario correr el comando docker compose up
Abrir su navegador en la url http://localhost:supuerto (por default http://localhost:8080)



