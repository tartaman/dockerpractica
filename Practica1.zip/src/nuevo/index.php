<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Holamundo</title>
    <style>
        img {width: 30em;}
        @keyframes anim {
            0% {
                background-color: red;
            }
            10% {
                background-color: orange;
            }
            20% {
                background-color:yellow;
            }
            30% {
                background-color: yellowgreen;

            }
            40% {
                background-color: cyan;

            }
            50% {
                background-color: blue;

            }
            60% {
                background-color: fuchsia;

            }
            70% {
                background-color: pink;

            }
            80% {
                background-color: purple;

            }
            100% {
                background-color: red;

            }
        }
    </style>
    
</head>
<body style="animation-name: anim; animation-duration: 5s; animation-fill-mode: both; animation-iteration-count: infinite;">
    <p style="width: 100%; ">
        i i folou <br>
        i folu yu didi liri
    </p>
    <hr style="border-color: black; border-width: 10px;">
    <div id ="id1" style="display: flex; flex-wrap: wrap;width: 100%;"> 
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <img src="https://preview.redd.it/dancing-toothless-v0-q18gv0dfd4ac1.gif?width=300&auto=webp&s=dbe1ad40abae0754e0e5ee5899b1a930e4806c01" alt="">
        <div style="display: flex; flex-wrap: wrap; flex-direction: row;">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
            <img src="https://media.tenor.com/qJRMLPlR3_8AAAAi/maxwell-cat.gif" alt="">
        </div>    
</div>
</body>
</html>